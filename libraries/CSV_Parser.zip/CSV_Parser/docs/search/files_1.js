var searchData=
[
  ['documentation_5fconfig_2etxt_21',['documentation_config.txt',['../documentation__config_8txt.html',1,'']]]
];
